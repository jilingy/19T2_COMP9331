import socket
import sys

#HOST, PORT = '127.0.0.1', 8000
HOST = '' 
PORT= int(sys.argv[1])
#IPV4 TCP
listen_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Allow to reuse the same address
listen_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#binds address to the socket(create connection)
listen_socket.bind((HOST, PORT))
#This passively accept TCP client connection, waiting until connection arrives (blocking).
listen_socket.listen(1)
# enable Http work all the time
while True:
    #accept request from client（browser）
    client_connection, client_address = listen_socket.accept()
    request = client_connection.recv(2048) # receive max byte
    request = request.decode() # byte -> string
    #print(request)
    if not request:
        continue
    #pattern = request[0:3]
    parsedRequest = request.split(' ')
    FileDirectory = parsedRequest[1]
    #print(FileDirectory)
    try :
        if FileDirectory == '/' or FileDirectory == '/index.html':
            file = open('index.html')
            response = '\nHTTP/1.1 200 OK\n\n' + file.read()
            response = response.encode()
            file.close()
            client_connection.sendall(response)# response to client
            #print('message has been sent')
            #client_connection.close()
        else :
            FileDirectory = FileDirectory[1:]
            requestFile = open(FileDirectory, 'rb')
            response = '\nHTTP/1.1 200 OK\n\n'.encode() + requestFile.read()
            requestFile.close()
            client_connection.sendall(response)
            #print('message has been sent')
            #client_connection.close()
    except FileNotFoundError:
        response = b'\nHTTP/1.1 404 Not Found\n\nError 404:I cannot find the file.' 
        client_connection.sendall(response)
        #print('message has been sent')
        client_connection.close()
